<?php

include('simpletest/autorun.php');

class test extends UnitTestCase {
	function searchProducts() {
  global $search;
  
  // Extract the data that was sent to server
  $user_keyword = $_GET['user_query'];

  // Display error if no products found else display the products
  if($search->count() == 0){
    echo "<div class='alert alert-danger' role='alert'><strong>Sorry!</strong> Your search <strong> ". $user_keyword ." </strong> did not match any products.</div>";
    echo "<center><img src='images/no-search-results.jpg'></center>"; 
    }
    else {
    echo "<div class='alert alert-success' role='alert'>Searched For: <strong> $user_keyword </strong></div>";
     foreach($search as $item) {
      ?>
        <div class="col-md-4 product-base">
           <a href ="product-details.php?pro_details=<?php echo $item['_id'] ?>"><img class="img-responsive img-thumbnail" src="images/products/<?php echo $item['image1']['name'] ?>">
              <div class="product"><?php echo $item['title'] ?></div>
              <span class="product-details">More Details</span>
              <span class="product-price">Price: £<?php echo $item['price'] ?></span>
           </a>
        </div>
    <?php
    }
  }
}
}


?>