<?php

include('simpletest/autorun.php');

class test extends UnitTestCase {



function price() {
  global $dbname;

  // Select from cart where email = email address
  $select_product = $dbname->cart->find(array("email" => $_SESSION['loggedInUserEmail']));

  foreach ($select_product as $pro) {
    $pro_id = $pro['pro_id'];
    $pro_price = $pro['price'];

    $value = $pro_price;
    $total += $value;
  }
  // Display result  
 echo $total;
}



}


?>