<?php

include('simpletest/autorun.php');

class test extends UnitTestCase {
  // Cart Page
 function cart() {
  global $dbname;
  
  if(isset($_GET['add_cart'])) {
    if(isset($_SESSION['loggedInUserEmail'])) {
    $p_id = $_GET['add_cart'];
 
    $cart_products = $dbname->products->find(array("_id" => new MongoId($_GET['add_cart'])));

    foreach($cart_products as $item) {
         $title = $item['title'];
         $price = $item['price'];
         $img = $item['image1'];
    } 
  
    // selecting a cart collection
    $basket = $dbname->cart;
    
    // Create a PHP array with our search criteria
    $findCustomer = [
      "pro_id" => $p_id
    ];

     // Find all of the customers that match this criteria
    $cursor = $dbname->cart->find($findCustomer);

    // Check that there is exactly one customer
    if($cursor->count() == 0){

      //Create a PHP array 
      $registerArray = [ 
        "pro_id" => $p_id,
        "email" => $_SESSION['loggedInUserEmail'],
        "title" => $title,
        "price" => $price,
        "image" => $img
      ];

      // Inserting Data to customers collections
      $result = $basket->insert($registerArray);

  }
  else if($cursor->count() > 0){
           echo '';
    }
  }
  else {
      echo "<script>alert('Please login to add product to cart!')</script>";
      echo "<script>window.open('login.php','_self')</script>";
    } 
  }
}

	








}


?>