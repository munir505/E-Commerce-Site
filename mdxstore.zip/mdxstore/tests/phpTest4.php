<?php

include('simpletest/autorun.php');

class test extends UnitTestCase {
  
function basket() {
  global $dbname;

  // Select from cart where email = email address
  $item = $dbname->cart->find(array("email" => $_SESSION['loggedInUserEmail']))->count();
  
  // Display result
  echo "<span class='badge alert-info fade in'>" . $item .  "</span>";
}



}


?>