<?php include('header.php'); ?>
<?php if(!array_key_exists("loggedInAdmin", $_SESSION)) {
    echo "<script>window.open('login.php','_self')</script>";
   }
   else {
      ?>
    <div class="container">
        <section class="section">
            <!-- begin of admin navigation -->
            <div class="row">
                <div class="col-md-3">
                    <a href="index.php" class="btn btn-info btn-block">Insert Product</a>
                </div>
                <div class="col-md-3">
                    <a href="manage_products.php" class="btn btn-info btn-block">Manage Product</a>
                </div>   
                <div class="col-md-3 product-base">
                    <a href="manage_orders.php" class="btn btn-info btn-block">Manage Orders</a>
                </div>
                <div class="col-md-3 product-base">
                    <a href="manage_users.php" class="btn btn-info btn-block">Manage Users</a>
                </div>
            </div>
            <!-- end of admin navigation -->

            <h2 class="text-center">Manage Orders - MDX Store</h2>
            <div class="row">
                <div class="col-md-12">
            <?php 
            // Return message when product addedd successfully. 
             echo $message; ?>
                    <!-- begin of manage products -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <b>Manage Orders</b>
                        </div>
                        <div class="panel-body">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order Id</th>
                                        <th>Product Name</th>
                                        <th>Customer Name</th>
                                        <th>Shipping Details</th>
                                        <th>Status</th>
                                        <th>
                                    </tr>
                                </thead>
                        <?php 
                            // fetching categories
                            foreach($orders as $item) {
                        ?>
                                <tbody>
                                    <tr>
                                        <td class="col-md-1"><?php echo $item['orderID'] ?></td>
                                        <td class="col-md-5">
                                            <div class="media">
                                                <a class="pull-left" href="#"><img class="img-responsive img-thumbnail" src="../images/products/<?php echo $item['image1']['name'] ?>" style="width: 72px; height: 72px;"></a>
                                                <h4 class="media-heading"><?php echo $item['pro_title'] ?></h4>
                                            </div>
                                        </td>
                                        <td class="col-md-2"><?php echo $item['username'] ?></td>

                                        <td class="col-md-2">
                                            <?php echo $item['address'] ?>
                                        </td>
                                        <td class="col-md-1 text-success"><?php echo $item['status'] ?></td>
                                        <td class="col-md-1">
                                            <button type="button" class="btn btn-danger">
                                                <span class="glyphicon glyphicon-remove"></span> Remove 
                                            </button>
                                        </td>


                                        <td class="col-md-1">
                                            <button type="button" class="btn btn-success">
                                                <span class="glyphicon glyphicon-ok"></span> Dispatched 
                                            </button>
                                        </td>
                                    </tr>
                                </tbody>
                         <?php } ?>
                            </table>
                        </div>
                    </div>
                    <!-- end of manage products -->
                </div>
            </div>
        </section>
    </div>
    <?php include('footer.php'); ?>
    <?php } ?>