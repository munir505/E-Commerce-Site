<?php include('header.php'); ?>
<div class="container wrapper">
   <hr />
   <div class="row">
	  <!-- begiin of calling the PHP search function -->
      <?php searchProducts(); ?>
      <!-- end of calling PHP search function -->
   </div>
</div>
<?php include('footer.php'); ?>