<?php include('header.php'); ?>
<div class="container wrapper">
   <div class="row">
      <!-- begin of left sidebar -->

      <div class="col-sm-2">
      <?php
      
      $_SESSION['cat_id'] = $_GET['cat_id'];

      ?>

      
         <ul class="list-unstyled">
         </ul>
         <div class="row">
            <hr />
            <div class="col-sm-2">
               <h5>Sorting</h5>
               <br>
               <form>
                   <div class="btn-group-vertical">
                   
                      <h6>Price</h6>
                      <button class="btn btn-link" type="button" onclick="loadContent()">££££</button>

                      <hr />

                      <button class="btn btn-link" type="button" onclick="loadContent2()">££</button>
                       
                      <hr />

                      <h6>Alphabetically</h6>
                      <button class="btn btn-link" type="button" onclick="decSort()">A - Z</button>

                      <hr />

                      <button class="btn btn-link" type="button" onclick="ascSort()">Z - A</button>

                   

                  </div>
               </form>
            </div>
         </div>
         
         <div class="row">
            <hr />
            <div class="col-sm-2">


            </div>
         </div>
      </div>
      <!-- end of left sidebar -->
      
      <script>
         function loadContent(){

            var request = new XMLHttpRequest();

            request.onload = function(){

               if(request.status === 200){
                  var responseData = request.responseText;

                  document.getElementById("ServerContent").innerHTML = responseData;
               }

               else

                  alert("Error" + request.status);
            };

            request.open("GET", "sort.php");

            request.send();
         }
         
         function ascSort(){

            var request = new XMLHttpRequest();

            request.onload = function(){

               if(request.status === 200){
                  var responseData = request.responseText;

                  document.getElementById("ServerContent").innerHTML = responseData;
               }

               else

                  alert("Error" + request.status);
            };

            request.open("GET", "sortAsc.php");

            request.send();
         }

         function decSort(){

            var request = new XMLHttpRequest();

            request.onload = function(){

               if(request.status === 200){
                  var responseData = request.responseText;

                  document.getElementById("ServerContent").innerHTML = responseData;
               }

               else

                  alert("Error" + request.status);
            };

            request.open("GET", "sortDec.php");

            request.send();
         }

         
         function loadContent2(){

            var request = new XMLHttpRequest();

            request.onload = function(){

               if(request.status === 200){
                  var responseData = request.responseText;

                  document.getElementById("ServerContent").innerHTML = responseData;
               }

               else

                  alert("Error" + request.status);
            };

            request.open("GET", "sort2.php");

            request.send();
         }
      </script>

      <!-- begin of right side -->
      <div class="col-sm-10">
         <!-- Breadcrumbs -->
         <div class="row">
            <div class="col-md-12">
               <ul class="breadcrumb">
                  <li><a href="index.php">Home</a></li>

                  <li><a href="#">Products</a></li>
               </ul>
            </div>
         </div>
         <!-- end of Breadcrumbs -->
         <hr>
         <!-- Displaying Products Using PHP function -->
         <div class="row" id="ServerContent">
         
            <?php 
   
             
            getProducts();

            ?>


         
         </div>
         <!-- end of Products -->
      </div>
      <!-- end of right side -->
   </div>
</div>
<!-- end of container -->
<?php include('footer.php'); ?>